java -jar jflex-full-1.7.0.jar examSpec.lex
javac Yylex.java