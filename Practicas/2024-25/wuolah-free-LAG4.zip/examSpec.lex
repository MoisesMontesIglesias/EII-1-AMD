import java.io.InputStreamReader;
import java.lang.System;

%%
%char
%public
%standalone
%full

DIGIT=([0-9])


%%

(\t|\n|" ")		{}
.*				{System.out.println("SCANNER:: LEXICAL ERROR ("+yytext()+")");}
